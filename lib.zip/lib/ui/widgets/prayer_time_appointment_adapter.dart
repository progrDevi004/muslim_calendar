import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:muslim_calendar/models/appointment_model.dart';
import 'package:muslim_calendar/data/services/prayer_time_service.dart';
import 'package:muslim_calendar/data/services/recurrence_service.dart';

class PrayerTimeAppointmentAdapter {
  final PrayerTimeService prayerTimeService;
  final RecurrenceService recurrenceService;

  PrayerTimeAppointmentAdapter({
    required this.prayerTimeService,
    required this.recurrenceService,
  });

  Future<List<Appointment>> getAppointmentsForRange(
    AppointmentModel model,
    DateTime startRange,
    DateTime endRange,
  ) async {
    List<Appointment> result = [];

    // Ohne Startzeit können wir nichts berechnen
    if (model.startTime == null) {
      return result;
    }

    // Einzeltermin (ohne Recurrence)
    if (model.recurrenceRule == null) {
      return _getSingleAppointments(model, startRange, endRange);
    } else {
      return _getRecurringAppointments(model, startRange, endRange);
    }
  }

  Future<List<Appointment>> _getSingleAppointments(
    AppointmentModel model,
    DateTime startRange,
    DateTime endRange,
  ) async {
    List<Appointment> result = [];

    if (model.isRelatedToPrayerTimes) {
      // Berechne einmalig basierend auf dem Startdatum
      final baseDate = DateTime(
          model.startTime!.year, model.startTime!.month, model.startTime!.day);
      final start =
          await prayerTimeService.getCalculatedStartTime(model, baseDate);
      final end = await prayerTimeService.getCalculatedEndTime(model, baseDate);

      if (start != null && end != null) {
        if ((start.isBefore(endRange) && end.isAfter(startRange))) {
          result.add(_toAppointment(model, start, end));
        }
      }
    } else {
      // Normaler Einzeltermin
      if (model.startTime != null && model.endTime != null) {
        final start = model.startTime!;
        final end = model.endTime!;
        if ((start.isBefore(endRange) && end.isAfter(startRange))) {
          result.add(_toAppointment(model, start, end));
        }
      }
    }

    return result;
  }

  Future<List<Appointment>> _getRecurringAppointments(
    AppointmentModel model,
    DateTime startRange,
    DateTime endRange,
  ) async {
    List<Appointment> result = [];
    final dates =
        recurrenceService.getRecurrenceDates(model, startRange, endRange);

    // Duplikate verhindern (falls aus irgendeinem Grund der RRule doppelte Daten liefert)
    final uniqueDates = <DateTime>{};
    for (var d in dates) {
      uniqueDates.add(DateTime(d.year, d.month, d.day, d.hour, d.minute));
    }

    for (var d in uniqueDates) {
      if (model.isRelatedToPrayerTimes) {
        // Für prayer-time-basierte Termine pro Tag neu berechnen
        final baseDate = DateTime(d.year, d.month, d.day);
        final start =
            await prayerTimeService.getCalculatedStartTime(model, baseDate);
        final end =
            await prayerTimeService.getCalculatedEndTime(model, baseDate);
        if (start != null && end != null) {
          if ((start.isBefore(endRange) && end.isAfter(startRange))) {
            result.add(_toAppointment(model, start, end));
          }
        }
      } else {
        // Wiederkehrender Termin ohne Gebetszeiten
        final baseDuration = (model.endTime != null && model.startTime != null)
            ? model.endTime!.difference(model.startTime!)
            : const Duration(minutes: 30);

        final originalStart = model.startTime!;
        // Wiederholungstermine basieren auf dem ursprünglichen Startzeitpunkt, aber mit dem Datum von d
        final start = DateTime(
            d.year, d.month, d.day, originalStart.hour, originalStart.minute);
        final end = start.add(baseDuration);

        if ((start.isBefore(endRange) && end.isAfter(startRange))) {
          result.add(_toAppointment(model, start, end));
        }
      }
    }

    return result;
  }

  Appointment _toAppointment(
      AppointmentModel model, DateTime start, DateTime end) {
    return Appointment(
      id: model.id,
      subject: model.subject,
      notes: model.notes,
      startTime: start,
      endTime: end,
      color: model.color,
      isAllDay: model.isAllDay,
      location: model.location,
      recurrenceRule: model.recurrenceRule,
      recurrenceExceptionDates: model.recurrenceExceptionDates,
    );
  }
}
