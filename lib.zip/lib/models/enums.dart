enum PrayerTime {
  fajr,
  dhuhr,
  asr,
  maghrib,
  isha,
}

enum TimeRelation {
  before,
  after,
}
